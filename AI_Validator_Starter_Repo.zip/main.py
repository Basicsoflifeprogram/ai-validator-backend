
from fastapi import FastAPI, Request
from pydantic import BaseModel
import openai
import os

app = FastAPI()

openai.api_key = os.getenv("OPENAI_API_KEY")

class QuizSubmission(BaseModel):
    student_id: str
    lesson_id: str
    answers: list

@app.post("/submit")
async def submit_quiz(submission: QuizSubmission):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an educational quiz grader. Score the student's answers (0–100%) and provide a brief reason."},
                {"role": "user", "content": f"Lesson: {submission.lesson_id}\nAnswers: {submission.answers}"}
            ]
        )
        feedback = response.choices[0].message['content']
        return {
            "student_id": submission.student_id,
            "lesson_id": submission.lesson_id,
            "score": "AI-graded",
            "feedback": feedback
        }
    except Exception as e:
        return {"error": str(e)}
